//
//  ViewController.swift
//  Vattikuti_WordGuess
//
//  Created by Vattiktui Manohar Sri Vikram on 10/17/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var wordsGuessedLabel: UILabel!
    
    @IBOutlet weak var wordsRemainingLabel: UILabel!
    
    @IBOutlet weak var totalWordsLabel: UILabel!
    
    @IBOutlet weak var userGuessLabel: UILabel!
    
    @IBOutlet weak var guessLetterField: UITextField!
    
    @IBOutlet weak var guessLetterButtonPressed: UIButton!
    
    @IBOutlet weak var hintLabel: UILabel!
    
    @IBOutlet weak var guessCountLabel: UILabel!
    
    @IBOutlet weak var statusLabel: UILabel!
    
    @IBOutlet weak var displayImage: UIImageView!
    
    var words = [["BIRYANI", "","Qdoba"],
    ["ANGULAR", "Programming Language","Angular"],
                 ["MAC","Apple Product","Mac"],
                 ["SACHIN","Got Of Cricket","Sachin"],
                 ["PIKACHU","Pi-kaPika","Pikachu"]]
    
    
    var count = 0;
    var word = ""
    var lettersGuessed = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func playAgainButtonPressed(_ sender: Any) {
    }
    
    @IBAction func guessLetterButtonPressed(_ sender: Any) {
    }
}

