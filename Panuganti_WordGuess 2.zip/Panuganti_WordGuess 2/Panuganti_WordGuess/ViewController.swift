//
//  ViewController.swift
//  Panuganti_WordGuess
//
//  Created by Sirisha Panuganti on 10/18/23.
//

import UIKit

class ViewController: UIViewController {

    var words = [["VANILLA", "Icecream flavour"],
                ["INDIA", "Country"],
                ["TENNIS", "Game"],
                ["LENOVO", "Laptop"],
                 ["TABLE","Furniture"]]
    var wordsGuessed = 0
    var wordsRemaining = 5
    var totalWords = 5
    //var guessLetter = guessLetterField.text!
    var count = 0;
        var word = ""
    let maxNumofWrongGuesses = 10
    

    @IBOutlet weak var wordsGuessedLabel: UILabel!
    
    @IBOutlet weak var wordsRemainingLabel: UILabel!
    
    @IBOutlet weak var totalWordsLabel: UILabel!
    
    @IBOutlet var userGuessLabel: UILabel!
    
    
    @IBOutlet weak var guessLetterField: UITextField!
    @IBOutlet weak var guessLetterButtonPressed: UIButton!
    
    @IBOutlet weak var hintLabel: UILabel!
    
    @IBOutlet weak var guessCountLabel: UILabel!
    
    @IBOutlet weak var statusLabel: UILabel!
    
    
    @IBAction func playAgainButtonPressed(_ sender: Any) {
    }
    
    
    @IBAction func guessLetterButtonPressed(_ sender: Any) {
        
        
    }
    @IBAction func guessLetterField(_ sender: Any) {
        var guessLetter = guessLetterField.text!
        guessLetter = String(guessLetter.last ?? " ").trimmingCharacters(in: .whitespaces);
        guessLetterField.text = guessLetter

        if guessLetter.isEmpty{
            guessLetterButtonPressed.isEnabled = false
                }
                else{
                    guessLetterButtonPressed.isEnabled = true
                }
    }
    
    @IBOutlet weak var displayImage: UIImageView!
    
  

    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        totalWordsLabel.text! = totalWordsLabel.text! + " " + String(totalWords)
        wordsGuessedLabel.text! = wordsGuessedLabel.text! + " " + String(wordsGuessed)
        wordsRemainingLabel.text! = wordsRemainingLabel.text! + " " + String(wordsRemaining)
        
        guessLetterButtonPressed.isEnabled = false;
        
        
       word = words[count][0]
                
        userGuessLabel.text = ""
                
            
                updateUnderscores();
                
                //Get the first hint from the array
        hintLabel.text = "Hint: "+words[count][1]
                
                //Clear the status label intially.
                statusLabel.text = ""
    }

    func updateUnderscores(){
            for letter in word{
                userGuessLabel.text! += "_ "
            }
        }

}

